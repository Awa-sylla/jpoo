import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Person {
    private String nom;
    private String prenom;
    private  String matricule;
    private int age;
    private Calendar date_naiss;

    public Person(String nom, String prenom, String matricule, int age, Calendar date_naiss) {
        this.nom = nom;
        this.prenom = prenom;
        this.matricule = genererMatricule();
        this.age = CalculAge();
        this.date_naiss = date_naiss;
    }

    public Person(String awa, String sylla, Calendar dateNaiss) {
    }


    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Calendar getDate_naiss() {
        return date_naiss;
    }

    public void setDate_naiss(Calendar date_naiss) {
        this.date_naiss = date_naiss;
        //this.age = CalculAge();
    }

    private String genererMatricule(){
        Random generer = new Random();
        int numerorandom = generer.nextInt(10000);
        String mat = prenom.charAt(0)+nom.charAt(0)+String.format("%04d",numerorandom);
        return mat;
    }

    public int CalculAge(){
        int Anniv = date_naiss.get(Calendar.YEAR);
        Calendar actuelle = Calendar.getInstance();
        int AnneeActuelle = actuelle.get(Calendar.YEAR);
        int age = AnneeActuelle - Anniv;
        return age;
    }
}