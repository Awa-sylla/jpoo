import java.util.Calendar;

public static void main(String[] args){
    Calendar date_naiss = Calendar.getInstance();
    date_naiss.set(2001,Calendar.JUNE, 3);

    Person person = new Person ("Awa","sylla",date_naiss);
    System.out.println("Nom" +person.getNom());
    System.out.println(("prenom" +person.getPrenom()));
    System.out.println("Matricule" +person.getMatricule());
    System.out.println(("age" +person.CalculAge()));

}

