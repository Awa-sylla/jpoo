import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

class Personne {
    protected String nom;
    protected Date dateNaissance;
    protected double taille;

    public Personne(String nom, Date dateNaissance, double taille) {
        this.nom = nom;
        this.dateNaissance = dateNaissance;
        this.taille = taille;
    }

    public void affichage() {
        System.out.println("Nom: " + nom + ", Date de Naissance: " + dateNaissance + ", Taille: " + taille);
    }

    @Override
    public String toString() {
        return "Nom: " + nom + ", Date de Naissance: " + dateNaissance + ", Taille: " + taille;
    }
}

class Employe extends Personne {
    private static int nombreTotalEmployes = 0;
    private static final double SalaireMinimum = 1000;

    private double salaire;
    private String poste;

    public Employe(String nom, double salaire) {
        super(nom, new Date(), 0);
        this.salaire = salaire;
        nombreTotalEmployes++;
    }

    public Employe(String nom, Date dateNaissance, String poste) {
        super(nom, dateNaissance, 0);
        this.poste = poste;
        nombreTotalEmployes++;
    }

    public static int getNombreTotalEmployes() {
        return nombreTotalEmployes;
    }

    public static double getSalaireMinimum() {
        return SalaireMinimum;
    }

    public void affichage() {
        System.out.println("Nom: " + nom + ", Salaire: " + salaire + ", Poste: " + poste);
    }

    @Override
    public String toString() {
        return "Nom: " + nom + ", Salaire: " + salaire + ", Poste: " + poste;
    }

    public static Employe creerEmployeAleatoire() {
        String nomAlea = genererCaractereAleatoire();
        double salaireAleatoire = Math.random() * (5000 - 1000) + 1000;
        return new Employe(nomAlea, salaireAleatoire);
    }

    private static String genererCaractereAleatoire() {
        String nouveau = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
        StringBuilder nomAlea = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            int dix = (int) (Math.random() * nouveau.length());
            nomAlea.append(nouveau.charAt(dix));
        }
        return nomAlea.toString();
    }
}


