import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;


public class Main {
    public static void main(String[] args) {
        ArrayList<Employe> employes = new ArrayList<>();


        employes.add(Employe.creerEmployeAleatoire());
        employes.add(new Employe("John Doe", 3000));
        employes.add(new Employe("Jane Doe", new Date(), "Manager"));


        System.out.println("=== Employés non triés ===");
        for (Employe employe : employes) {
            employe.affichage();
        }


        Collections.sort(employes, (e1, e2) -> e1.nom.compareTo(e2.nom));


        System.out.println("\n=== Employés triés ===");
        for (Employe employe : employes) {
            employe.affichage();
        }
    }
}